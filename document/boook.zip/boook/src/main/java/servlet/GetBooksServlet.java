package servlet;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import dto.books;
import dto.UserReg;
import dto.PageInfo;
import service.BooksModel;
import service.UserModel;
import java.lang.Math;
/**
 * Servlet implementation class GetStudentsServlet
 */
@WebServlet("/GetBooksServlet")
public class GetBooksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetBooksServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");
		BooksModel sb = new BooksModel();
		ArrayList<books> books;
		int curPage = Integer.parseInt(request.getParameter("curPage"));
		int pageSize = Integer.parseInt(request.getParameter("pageSize"));
		books = sb.getBooks(curPage, pageSize);
		PageInfo pi = new PageInfo();
		pi.setPageNum(curPage);
		pi.setPageSize(pageSize);
		pi.setTotalRows(sb.getBooksQty());
		request.setAttribute("books", books);
		request.setAttribute("pageInfo", pi);
		RequestDispatcher dis = request.getRequestDispatcher("studentsEditor.jsp");
		dis.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
