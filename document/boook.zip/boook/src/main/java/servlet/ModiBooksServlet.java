package servlet;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException; 
import java.text.SimpleDateFormat; 
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.net.URLDecoder;
import dto.books;
import service.BooksModel;
/**
 * Servlet implementation class ModiStudentServlet
 */
@WebServlet("/ModiBooksServlet")
@MultipartConfig
public class ModiBooksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModiBooksServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		BooksModel sb = new BooksModel();
		books s = new books();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		int objId = Integer.parseInt(request.getParameter("objId"));
		s.setId(objId);
		s.setBookId(request.getParameter("booksId"));
		s.setName(URLDecoder.decode(request.getParameter("name"), "UTF-8"));
		s.setScore(URLDecoder.decode(request.getParameter("score"), "UTF-8"));
		s.setWriter(URLDecoder.decode(request.getParameter("writer"), "UTF-8"));

		try {
			s.setEnrollDate(df.parse(request.getParameter("dateIssued")));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		s.setPicFile(null);
	
		if(-1 != sb.updateStudent(s)) {
			response.setCharacterEncoding("utf-8");
			response.setContentType("application/text; charset=UTF-8");
			response.getWriter().print("y");
		}
		else {
			response.getWriter().print("n");
		}
	}

}
