package service;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import dto.books;

public class BooksModel {
	public ArrayList<books> getBooks(int curPage, int pageSize){
		ArrayList<books> books = null;
		Connection con = ConnectionPool.getInstance().getConnection();
		if(con != null) {
			books = new ArrayList<books>();
			PreparedStatement st = null;
			ResultSet rs = null;
			try {
				st = con.prepareStatement("select id, booksId, name, score, dateIssued,writer, picFile from book limit ?, ?");
				st.setInt(1, (curPage - 1) * pageSize);
				st.setInt(2, pageSize);
				rs = st.executeQuery();
				while(rs.next()) {
					books s = new books();
					s.setId(rs.getInt(1));
					s.setBookId(rs.getString(2));
					s.setName(rs.getString(3));
					s.setScore(rs.getString(4));
					s.setEnrollDate(rs.getDate(5));
					s.setWriter(rs.getString(6));
					s.setPicFile(rs.getString(7));
					books.add(s);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if(rs != null) rs.close();
					if(st != null) st.close();
					ConnectionPool.getInstance().returnConnection(con);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return books;
	}
	
	public int getBooksQty() {
		int r = -1;  //如果返回-1，表示没有获得连接，应该稍后再试。
		Connection con = ConnectionPool.getInstance().getConnection();
		if(con != null) {
			Statement st = null;
			ResultSet rs = null;
			try {
				st = con.createStatement();
				rs = st.executeQuery("select count(*) from book");
				if(rs.next()) {
					r = rs.getInt(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if(rs != null) rs.close();
					if(st != null) st.close();
					ConnectionPool.getInstance().returnConnection(con);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return r;
	}
public int delBooks(int id) {
		int r = -1;  //如果返回-1，表示没有获得连接，应该稍后再试。
		Connection con = ConnectionPool.getInstance().getConnection();
		if(con != null) {
			PreparedStatement st = null;
			try {
				st = con.prepareStatement("delete from book where id=?");
				st.setInt(1, id);
				r = st.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if(st != null) st.close();
					ConnectionPool.getInstance().returnConnection(con);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return r;
	}
public int insertBooks(books s) {
		int r = -1;  //如果返回-1，表示没有获得连接，应该稍后再试。
		Connection con = ConnectionPool.getInstance().getConnection();
		if(con != null) {
			PreparedStatement st = null;
			try {
				if(s.getPicFile()!=null) {
					st = con.prepareStatement("insert into book (booksId, name, score,dateIssued,writer,picFile) values (?,?,?,?,?,?)");
					st.setString(1, s.getBookId());
					st.setString(2, s.getName());
					st.setString(3, s.getScore());
                    st.setDate(4, new Date(s.getEnrollDate().getTime()));
					st.setString(5, s.getWriter());
					st.setString(6, s.getPicFile());
				}
				else {
					st = con.prepareStatement("insert into student (studentId, citizenId, name, school, gender, enrollDate) values (?,?,?,?,?,?)");
					st.setString(1, s.getBookId());
					st.setString(2, s.getName());
					st.setString(3, s.getScore());
                    st.setDate(4, new Date(s.getEnrollDate().getTime()));
					st.setString(5, s.getWriter());
				}
				r = st.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if(st != null) st.close();
					ConnectionPool.getInstance().returnConnection(con);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return r;
	}
	public int updateStudent(books s) {
		int r = -1;  //如果返回-1，表示没有获得连接，应该稍后再试。
		Connection con = ConnectionPool.getInstance().getConnection();
		if(con != null) {
			PreparedStatement st = null;
			try {
				if(s.getPicFile()!=null) {
					st = con.prepareStatement("update book set booksId=?, name=?, score=?,dateIssued=?,writer=?,  picFile=? where id=?");
					st.setString(1, s.getBookId());
					st.setString(2, s.getName());
					st.setString(3, s.getScore());
                    st.setDate(4, new Date(s.getEnrollDate().getTime()));
					st.setString(5, s.getWriter());
                    st.setString(6, s.getPicFile());
					st.setInt(7, s.getId());
				}
				else {
					st = con.prepareStatement("update book set booksId=?, name=?, score=?,dateIssued=?,writer=?,  where id=?");
					st.setString(1, s.getBookId());
					st.setString(2, s.getName());
					st.setString(3, s.getScore());
                    st.setDate(4, new Date(s.getEnrollDate().getTime()));
					st.setString(5, s.getWriter());
					st.setInt(6, s.getId());
				}
				r = st.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if(st != null) st.close();
					ConnectionPool.getInstance().returnConnection(con);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return r;
	}
}
