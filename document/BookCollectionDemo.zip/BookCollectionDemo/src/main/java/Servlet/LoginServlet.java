package Servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 获取用户输入的用户名和密码
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 在实际应用中，这里可以与数据库中存储的用户名和密码进行比较

        // 假设用户名和密码都正确
        if ("admin".equals(username) && "password".equals(password)) {
            // 登录成功，将用户重定向到ZBook主界面
            response.sendRedirect("index.jsp");
        } else {
            // 登录失败，返回到登录页面
            response.sendRedirect("login.jsp");
        }
    }
}